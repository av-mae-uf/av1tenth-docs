import sys
import math
import numpy as np
import matplotlib.pyplot as plt

from route_support import *

D2R = np.pi/180.0
R2D = 180.0/np.pi

def print_route_pose(pose):
    print(f'pt = {pose.pt}\theading_deg = {pose.heading_rad*R2D:.2f}\
        \tstate = {pose.state}\
        \tw1 = {pose.w1_for_subsequent_segment}\
        \tw2 = {pose.w2_for_subsequent_segment}'
        )

def print_route_segment(seg):
    print('\n')
    print(f'p0 = {seg.p0}')
    print(f'p1 = {seg.p1}')
    print(f'p2 = {seg.p2}')
    print(f'p3 = {seg.p3}')
    print(f'w1 = {seg.w1}, w2 = {seg.w2}, state = {seg.state}')

# ---------------------------------------------------------------
# make sure the name of the input and output files were specified
if len(sys.argv) != 2:
   print('useage:  python3 make_route_segs.py input_file.txt\n')
   exit()
   
# ---------------------------------------------------------------
# make sure the input file exists and can be opened 

input_file = sys.argv[1]

try:
    a_file = open(input_file)
except IOError:
    print ("Could not open the file ", sys.argv[1])
    exit()

stream = open(input_file, 'r')
# ---------------------------------------------------------------
# read in the poses and store in a list
route_poses = []

while True:
    line = stream.readline()
    if not line:
        break ;
        
    if(line[0] != '#' ):  # this will eliminate comment lines
        split_text  = line.split(',')

        if len(split_text) == 4 :
            xval = float(split_text[0])
            yval = float(split_text[1])
            zval = 0.0
            new_pose = route_pose_class(pt= np.array([xval, yval, zval]), \
                                  heading_rad= D2R*float(split_text[2]), \
                                  state=int(split_text[3].strip('\n')),\
                                  w1_for_subsequent_segment = 1.0, \
                                  w2_for_subsequent_segment = 1.0)
            route_poses.append(new_pose)
# ---------------------------------------------------------------
# ---------------------------------------------------------------
# we have our list of poses and are ready to generate a list of path segments           
for pose in route_poses:
    #print_route_pose(pose)
    pass

want_loop = False
dist_between_pts = 0.1

route_segments = create_route_segments(route_poses, want_loop, dist_between_pts)

i=0
for seg in route_segments:
    #print(f'\nseg num = {i}')
    #print_route_segment(seg)
    i = i+1

# ---------------------------------------------------------------
# draw four figures: 1)poses 2)control segments 3) smooth segments
#     4) heading angles

plt.figure()  # first figure

xh = [0.0, 0.0]  # allocate variables
yh = [0.0, 0.0]
for pose in route_poses:
    c1 = plt.Circle((pose.pt[0], pose.pt[1]), 0.5, color='black')
    xh[0] = pose.pt[0]
    yh[0] = pose.pt[1]
    xh[1] = xh[0] + 1.0*math.cos(pose.heading_rad)
    yh[1] = yh[0] + 1.0*math.sin(pose.heading_rad)
    plt.gca().add_artist(c1)
    plt.plot(xh,yh, color='turquoise')

plt.xlabel('UTM Easting (m)')
plt.ylabel('UTM Northing (m)')
plt.axis('equal')
plt.show(block = False)
plt.pause(0.1)
# ---------------------------------------------------------------
plt.figure()  # second figure

for seg in route_segments:
    c1 = plt.Circle((seg.p0[0], seg.p0[1]), 0.5, color='black')
    c2 = plt.Circle((seg.p1[0], seg.p1[1]), 0.25, color='blue')
    c3 = plt.Circle((seg.p2[0], seg.p2[1]), 0.25, color='blue')
    if seg.state != 12:
        c4 = plt.Circle((seg.p3[0], seg.p3[1]), 0.5, color='black')
    else:
        c4 = plt.Circle((seg.p3[0], seg.p3[1]), 0.5, color='orange')
    plt.gca().add_artist(c1)
    plt.gca().add_artist(c2)
    plt.gca().add_artist(c3)
    plt.gca().add_artist(c4)

# now draw a line connecting the control points in order
xline = []
yline = []
for seg in route_segments:
    xline.append(seg.p0[0])
    xline.append(seg.p1[0])
    xline.append(seg.p2[0])
    xline.append(seg.p3[0])
    yline.append(seg.p0[1])
    yline.append(seg.p1[1])
    yline.append(seg.p2[1])
    yline.append(seg.p3[1])
    
plt.plot(xline, yline, color = 'blue')

plt.xlabel('UTM Easting (m)')
plt.ylabel('UTM Northing (m)')
plt.axis('equal')
plt.show(block = False)
plt.pause(0.1)

# ---------------------------------------------------------------
# third figure

plt.figure()

xh = [0.0, 0.0]  # allocate variables
yh = [0.0, 0.0]
for pose in route_poses:
    c1 = plt.Circle((pose.pt[0], pose.pt[1]), 0.5, color='black')
    xh[0] = pose.pt[0]
    yh[0] = pose.pt[1]
    xh[1] = xh[0] + 1.0*math.cos(pose.heading_rad)
    yh[1] = yh[0] + 1.0*math.sin(pose.heading_rad)
    plt.gca().add_artist(c1)
    plt.plot(xh,yh, color='turquoise')

# now draw the smooth paths for each route segment
xr = []  # allocate variables
yr = []

for seg in route_segments:
    for u in np.arange(0.0, 1.0, 0.01):
        newpt = seg.get_point(u)
        xr.append(newpt[0])
        yr.append(newpt[1])

plt.plot(xr,yr, color='orange')

plt.xlabel('UTM Easting (m)')
plt.ylabel('UTM Northing (m)')
plt.axis('equal')
plt.show(block = False)
plt.pause(0.1)

# ---------------------------------------------------------------
# fourth figure

plt.figure()

i=0
x_i = []
heading_deg_i = []

for seg in route_segments:
    for u in np.arange(0.0, 1.0, 0.01):
        heading_deg_i.append( R2D*get_heading_rad_at_u(seg, u))
        x_i.append(i)

        i = i+1
        
plt.plot(x_i,heading_deg_i, color='green')

i=0
for seg in route_segments:
    x_i = []
    rad_of_curvature_i = []
    for u in np.arange(0.0, 1.0, 0.01):
        rad_of_curvature_i.append(get_radius_at_u(seg,u))
        x_i.append(i)
        i = i+1
        
    plt.plot(x_i,rad_of_curvature_i, color = 'violet')

plt.legend(["heading angle (deg)", "rad of curvature (m)"], loc="lower right")

plt.xlabel('i')
plt.ylabel('value')
#plt.axis('equal')

plt.show(block = True)